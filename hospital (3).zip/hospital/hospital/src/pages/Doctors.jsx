import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import { Search, Star, Award, Building2 } from 'lucide-react'
import './Doctors.css'

const Doctors = () => {
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedSpecialty, setSelectedSpecialty] = useState('all')

  const specialties = [
    'all',
    'Cardiac Surgeon',
    'Orthopedic Surgeon',
    'Neurosurgeon',
    'Oncologist',
    'ENT Surgeon',
    'Ophthalmologist',
    'Transplant Surgeon',
    'Cosmetic Surgeon',
  ]

  const doctors = [
    {
      id: 1,
      name: 'Dr. Rajeev Verma',
      specialty: 'Orthopedic Surgeon',
      hospital: 'Manipal Hospital',
      location: 'Dwarka, Delhi',
      rating: 4.9,
      experience: '15+ years',
      image: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=300',
    },
    {
      id: 2,
      name: 'Dr. Sunil Prakash',
      specialty: 'Transplant Surgeon',
      hospital: 'BLK Hospital',
      location: 'New Delhi',
      rating: 4.8,
      experience: '20+ years',
      image: 'https://images.unsplash.com/photo-1582750433449-648ed127bb54?w=300',
    },
    {
      id: 3,
      name: 'Dr. Yugal K Mishra',
      specialty: 'Cardiac Surgeon',
      hospital: 'Manipal Hospital',
      location: 'Dwarka, Delhi',
      rating: 4.9,
      experience: '18+ years',
      image: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=300',
    },
    {
      id: 4,
      name: 'Dr. Abhideep Chaudhary',
      specialty: 'Transplant Surgeon',
      hospital: 'BLK Hospital',
      location: 'New Delhi',
      rating: 4.7,
      experience: '16+ years',
      image: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=300',
    },
    {
      id: 5,
      name: 'Dr. W B S Ramalingam',
      specialty: 'ENT Surgeon',
      hospital: 'BLK Hospital',
      location: 'New Delhi',
      rating: 4.8,
      experience: '22+ years',
      image: 'https://images.unsplash.com/photo-1582750433449-648ed127bb54?w=300',
    },
    {
      id: 6,
      name: 'Dr. Subhash Chandra',
      specialty: 'Cardiac Surgeon',
      hospital: 'BLK Hospital',
      location: 'New Delhi',
      rating: 4.6,
      experience: '14+ years',
      image: 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=300',
    },
    {
      id: 7,
      name: 'Dr. Krishna S Iyer',
      specialty: 'Cardiac Surgeon',
      hospital: 'Fortis Escorts Heart Hospital',
      location: 'New Delhi',
      rating: 4.9,
      experience: '25+ years',
      image: 'https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=300',
    },
    {
      id: 8,
      name: 'Dr. Nitin Leekha',
      specialty: 'General Surgeon',
      hospital: 'Jaypee Hospital',
      location: 'Noida',
      rating: 4.7,
      experience: '12+ years',
      image: 'https://images.unsplash.com/photo-1582750433449-648ed127bb54?w=300',
    },
  ]

  const filteredDoctors = doctors.filter(doctor => {
    const matchesSearch = 
      doctor.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doctor.specialty.toLowerCase().includes(searchQuery.toLowerCase()) ||
      doctor.hospital.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesSpecialty = selectedSpecialty === 'all' || doctor.specialty === selectedSpecialty
    return matchesSearch && matchesSpecialty
  })

  return (
    <div className="doctors-page">
      <section className="page-hero">
        <div className="container">
          <h1 className="page-title">Top Doctors in India</h1>
          <p className="page-subtitle">
            Connect with experienced and highly-rated medical professionals
          </p>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="filters-section">
            <div className="search-bar">
              <Search className="search-icon" size={20} />
              <input
                type="text"
                placeholder="Search doctors by name, specialty, or hospital..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="search-input"
              />
            </div>

            <div className="specialty-filters">
              <label>Filter by Specialty:</label>
              <div className="specialty-buttons">
                {specialties.map(specialty => (
                  <button
                    key={specialty}
                    className={`specialty-btn ${selectedSpecialty === specialty ? 'active' : ''}`}
                    onClick={() => setSelectedSpecialty(specialty)}
                  >
                    {specialty === 'all' ? 'All Specialties' : specialty}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="results-info">
            <p>Found {filteredDoctors.length} doctors</p>
          </div>

          <div className="doctors-grid">
            {filteredDoctors.map(doctor => (
              <div key={doctor.id} className="doctor-card">
                <div className="doctor-image">
                  <img src={doctor.image} alt={doctor.name} />
                  <div className="doctor-rating">
                    <Star size={16} fill="#fbbf24" color="#fbbf24" />
                    <span>{doctor.rating}</span>
                  </div>
                </div>
                <div className="doctor-content">
                  <h3 className="doctor-name">{doctor.name}</h3>
                  <div className="doctor-specialty">
                    <Award size={16} />
                    <span>{doctor.specialty}</span>
                  </div>
                  <div className="doctor-hospital">
                    <Building2 size={16} />
                    <span>{doctor.hospital}</span>
                  </div>
                  <div className="doctor-location">
                    <span>{doctor.location}</span>
                  </div>
                  <div className="doctor-experience">
                    <span>Experience: {doctor.experience}</span>
                  </div>
                  <div className="doctor-actions">
                    <Link to="/contact" className="btn btn-primary">
                      Book Appointment
                    </Link>
                    <Link to="/hospitals" className="btn btn-outline">
                      View Hospital
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {filteredDoctors.length === 0 && (
            <div className="no-results">
              <p>No doctors found. Try adjusting your search or filters.</p>
            </div>
          )}
        </div>
      </section>
    </div>
  )
}

export default Doctors

