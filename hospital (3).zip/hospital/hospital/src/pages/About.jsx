import React from 'react'
import { Link } from 'react-router-dom'
import { Target, Award, Users, Heart } from 'lucide-react'
import './About.css'

const About = () => {
  return (
    <div className="about-page">
      <section className="page-hero">
        <div className="container">
          <h1 className="page-title">About Us</h1>
          <p className="page-subtitle">
            Your trusted partner in medical tourism
          </p>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="about-content">
            <div className="about-intro">
              <h2 className="content-title">Afyaassist India</h2>
              <p className="content-text">
                <strong>Afyaassist India</strong> (Patient Smile is Our Logo) is a most trusted name 
                in the world with years of experience in the healthcare industry. We are an 
                ISO-certified company and a trusted provider of one of the best treatments in 
                India at an affordable cost.
              </p>
              <p className="content-text">
                Our mission is to make world-class healthcare accessible to everyone, regardless 
                of their location or financial constraints. We partner with top hospitals and 
                doctors across India to provide comprehensive medical tourism services.
              </p>
            </div>

            <div className="vision-mission">
              <div className="vm-card">
                <div className="vm-icon">
                  <Target size={40} />
                </div>
                <h3>Our Vision</h3>
                <p>
                  To become the largest and fastest-growing provider of healthcare excellence 
                  in India with state-of-the-art medical facilities and comprehensive medical 
                  services based on the highest International Standards in the medical tourism industry.
                </p>
              </div>
              <div className="vm-card">
                <div className="vm-icon">
                  <Heart size={40} />
                </div>
                <h3>Our Mission</h3>
                <p>
                  To provide affordable, high-quality medical treatment to international and 
                  domestic patients by connecting them with the best hospitals, doctors, and 
                  treatment options while ensuring a seamless and comfortable experience.
                </p>
              </div>
            </div>

            <div className="why-choose">
              <h2 className="content-title">Why Choose Us?</h2>
              <div className="features-grid">
                <div className="feature-card">
                  <Award size={32} />
                  <h3>15+ Years Experience</h3>
                  <p>Extensive experience in medical tourism industry</p>
                </div>
                <div className="feature-card">
                  <Users size={32} />
                  <h3>3000+ Happy Patients</h3>
                  <p>Successfully served patients from around the world</p>
                </div>
                <div className="feature-card">
                  <Heart size={32} />
                  <h3>50+ Top Hospitals</h3>
                  <p>Network of world-class hospitals across India</p>
                </div>
                <div className="feature-card">
                  <Target size={32} />
                  <h3>200+ Top Doctors</h3>
                  <p>Access to highly qualified and experienced doctors</p>
                </div>
              </div>
            </div>

            <div className="services-overview">
              <h2 className="content-title">Our Services</h2>
              <p className="content-text">
                Afyaassist India helps you choose the best Hospitals in India, the Best Doctors 
                in India (as per the success rate of the surgery), and the best Cost.
              </p>
              <div className="services-list">
                <div className="service-item">
                  <span className="service-number">1</span>
                  <div>
                    <h4>Free Medical Visa Letter</h4>
                    <p>Get free medical invitation visa letter from hospital</p>
                  </div>
                </div>
                <div className="service-item">
                  <span className="service-number">2</span>
                  <div>
                    <h4>Doctor Appointment</h4>
                    <p>Appointment with doctor on arrival on urgent basis</p>
                  </div>
                </div>
                <div className="service-item">
                  <span className="service-number">3</span>
                  <div>
                    <h4>Airport Transfer</h4>
                    <p>Free pick-up and drop from the airport</p>
                  </div>
                </div>
                <div className="service-item">
                  <span className="service-number">4</span>
                  <div>
                    <h4>Hotel Booking</h4>
                    <p>Book a hotel near the hospital</p>
                  </div>
                </div>
                <div className="service-item">
                  <span className="service-number">5</span>
                  <div>
                    <h4>Interpreter Assistance</h4>
                    <p>Professional interpreter assistance available</p>
                  </div>
                </div>
                <div className="service-item">
                  <span className="service-number">6</span>
                  <div>
                    <h4>24/7 Support</h4>
                    <p>Round the clock assistance throughout your journey</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="cta-section">
              <h2>Ready to Start Your Medical Journey?</h2>
              <p>Get a free quote and personalized treatment plan</p>
              <Link to="/contact" className="btn btn-primary btn-large">
                Get Free Quote
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

export default About

