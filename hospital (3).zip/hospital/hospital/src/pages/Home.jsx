import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import { Search, Users, Building2, UserCheck, TrendingDown, Star } from 'lucide-react'
import './Home.css'

const Home = () => {
  const [searchQuery, setSearchQuery] = useState('')
  const [searchType, setSearchType] = useState('treatments')

  const stats = [
    { icon: <Users size={40} />, number: '3000+', label: 'Happy Patients' },
    { icon: <Building2 size={40} />, number: '50+', label: 'Top Hospitals' },
    { icon: <UserCheck size={40} />, number: '200+', label: 'Top Doctors' },
    { icon: <TrendingDown size={40} />, number: '20%', label: 'Savings' },
  ]

  const packages = [
    {
      id: 1,
      title: 'Hip Replacement In India',
      doctor: 'Dr. Rajeev Verma',
      hospital: 'Manipal Hospital',
      location: 'Dwarka - India',
      originalPrice: 8000,
      discountedPrice: 6500,
      image: 'https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=400',
    },
    {
      id: 2,
      title: 'Kidney Transplant',
      doctor: 'Dr. Sunil Prakash',
      hospital: 'BLK Hospital',
      location: 'New Delhi - India',
      originalPrice: 16000,
      discountedPrice: 14000,
      image: 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=400&h=300&fit=crop',
    },
    {
      id: 3,
      title: 'Bypass Surgery',
      doctor: 'Dr. Yugal K Mishra',
      hospital: 'Manipal Hospital',
      location: 'Dwarka - India',
      originalPrice: 7000,
      discountedPrice: 5400,
      image: 'https://images.unsplash.com/photo-1551601651-2a8555f1a136?w=400',
    },
    {
      id: 4,
      title: 'Liver Transplant Surgery',
      doctor: 'Dr. Abhideep Chaudhary',
      hospital: 'BLK Hospital',
      location: 'New Delhi - India',
      originalPrice: 40000,
      discountedPrice: 34000,
      image: 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=400',
    },
    {
      id: 5,
      title: 'Knee Replacement',
      doctor: 'Dr. Rajeev Verma',
      hospital: 'Manipal Hospital',
      location: 'Dwarka - India',
      originalPrice: 5000,
      discountedPrice: 3900,
      image: 'https://images.unsplash.com/photo-1559757175-0eb30cd8c063?w=400',
    },
    {
      id: 6,
      title: 'Cochlear Implant',
      doctor: 'Dr. W B S Ramalingam',
      hospital: 'BLK Hospital',
      location: 'New Delhi - India',
      originalPrice: 19800,
      discountedPrice: 17000,
      image: 'https://images.unsplash.com/photo-1582750433449-648ed127bb54?w=400',
    },
  ]

  const testimonials = [
    {
      name: 'Merag',
      country: 'Ethiopia',
      hospital: 'Jaypee Hospital',
      rating: 5,
      text: 'I am Merag from Ethiopia came to India for my general health check-up. Afyaassist offers me the complete package including Pick-up from the airport, hotel services, and 24 hours assistance. They guide you to choose best hospitals in india, best cost of treatment with topmost doctors...',
    },
    {
      name: 'Misfin Fikru',
      country: 'Ethiopia',
      hospital: 'Jaypee Hospital',
      rating: 5,
      text: 'I Misfin from Ethiopia came to Jaypee Hospital for my surgery and the surgery was successfully done. I really thank my surgeon Dr. Nitin Leekha, his entire team and especially the Afyaassist team. we appreciate their personal care throughout my journey...',
    },
    {
      name: 'Peter Louis',
      country: 'South Sudan',
      hospital: 'Jaypee Hospital',
      rating: 5,
      text: 'I am Peter Louis working as a press reporter in South Sudan came to Jaypee Hospital for my general health check-up. I was extremely pleased to be treated by professional staff in an excellent environment. Their packages were very cost-effective and offer a higher quality of care...',
    },
    {
      name: 'Mizan',
      country: 'Bangladesh',
      hospital: 'Fortis Escort Hospital',
      rating: 5,
      text: 'I am Mizan from Dhaka, Bangladesh came to India for my father-in-law cardiac surgery at Fortis Escort Hospital. I was confused to choose the best surgeon for him before coming, but Afyaassist helps me to choose the best hospital and best cardiac surgeon in India with very good cost...',
    },
  ]

  const handleSearch = (e) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      // Navigate to treatments page with search query
      window.location.href = `/treatments?search=${encodeURIComponent(searchQuery)}&type=${searchType}`
    }
  }

  return (
    <div className="home">
      {/* Hero Section */}
      <section className="hero">
        <div className="container">
          <div className="hero-content">
            <h1 className="hero-title">
              We Help You Choose the Best
              <span className="highlight"> Hospital, Doctor & Cost</span>
            </h1>
            <p className="hero-subtitle">
              Find world-class medical treatment in India at affordable prices. 
              Connect with top doctors and hospitals with guaranteed savings up to 20%.
            </p>
            
            <form className="search-box" onSubmit={handleSearch}>
              <div className="search-tabs">
                <button
                  type="button"
                  className={`search-tab ${searchType === 'treatments' ? 'active' : ''}`}
                  onClick={() => setSearchType('treatments')}
                >
                  Treatments
                </button>
                <button
                  type="button"
                  className={`search-tab ${searchType === 'hospitals' ? 'active' : ''}`}
                  onClick={() => setSearchType('hospitals')}
                >
                  Hospitals
                </button>
                <button
                  type="button"
                  className={`search-tab ${searchType === 'doctors' ? 'active' : ''}`}
                  onClick={() => setSearchType('doctors')}
                >
                  Doctors
                </button>
              </div>
              <div className="search-input-group">
                <Search className="search-icon" size={20} />
                <input
                  type="text"
                  placeholder={`Search for ${searchType}...`}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="search-input"
                />
                <button type="submit" className="btn btn-primary search-btn">
                  Search
                </button>
              </div>
            </form>

            <div className="hero-badge">
              <span className="badge-text">Guaranteed Savings up to 20%</span>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="stats-section">
        <div className="container">
          <div className="stats-grid">
            {stats.map((stat, idx) => (
              <div key={idx} className="stat-card">
                <div className="stat-icon">{stat.icon}</div>
                <div className="stat-number">{stat.number}</div>
                <div className="stat-label">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Packages Section */}
      <section className="section packages-section">
        <div className="container">
          <h2 className="section-title">Our Packages / Offers</h2>
          <p className="section-subtitle">
            Choose from our curated medical packages with best doctors and hospitals
          </p>
          
          <div className="packages-grid">
            {packages.map((pkg) => (
              <div key={pkg.id} className="package-card">
                <div className="package-image">
                  <img 
                    src={pkg.image} 
                    alt={pkg.title}
                    onError={(e) => {
                      e.target.onerror = null;
                      e.target.src = 'https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=400';
                    }}
                  />
                  <div className="package-badge">Special Offer</div>
                </div>
                <div className="package-content">
                  <h3 className="package-title">{pkg.title}</h3>
                  <div className="package-info">
                    <p className="package-doctor">{pkg.doctor}</p>
                    <p className="package-hospital">{pkg.hospital}</p>
                    <p className="package-location">{pkg.location}</p>
                  </div>
                  <div className="package-pricing">
                    <span className="original-price">${pkg.originalPrice.toLocaleString()}</span>
                    <span className="discounted-price">${pkg.discountedPrice.toLocaleString()}</span>
                  </div>
                  <Link to="/contact" className="btn btn-primary package-btn">
                    Book Now
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="section testimonials-section">
        <div className="container">
          <h2 className="section-title">Patient Testimonials</h2>
          <p className="section-subtitle">
            Hear from our satisfied patients from around the world
          </p>
          
          <div className="testimonials-grid">
            {testimonials.map((testimonial, idx) => (
              <div key={idx} className="testimonial-card">
                <div className="testimonial-header">
                  <div className="testimonial-rating">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} size={16} fill="#fbbf24" color="#fbbf24" />
                    ))}
                  </div>
                  <div className="testimonial-author">
                    <h4 className="author-name">{testimonial.name}</h4>
                    <p className="author-details">
                      From: {testimonial.country} | Hospital: {testimonial.hospital}
                    </p>
                  </div>
                </div>
                <p className="testimonial-text">"{testimonial.text}"</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="section services-section">
        <div className="container">
          <h2 className="section-title">Our Services</h2>
          <p className="section-subtitle">
            Comprehensive medical tourism services to make your journey smooth
          </p>
          
          <div className="services-grid">
            <div className="service-card">
              <div className="service-icon">📋</div>
              <h3>Free Medical Visa Letter</h3>
              <p>Get free medical invitation visa letter from hospital</p>
            </div>
            <div className="service-card">
              <div className="service-icon">👨‍⚕️</div>
              <h3>Doctor Appointment</h3>
              <p>Appointment with doctor on arrival on urgent basis</p>
            </div>
            <div className="service-card">
              <div className="service-icon">🚗</div>
              <h3>Airport Transfer</h3>
              <p>Free pick-up and drop from the airport</p>
            </div>
            <div className="service-card">
              <div className="service-icon">🏨</div>
              <h3>Hotel Booking</h3>
              <p>Book a hotel near the hospital</p>
            </div>
            <div className="service-card">
              <div className="service-icon">🌐</div>
              <h3>Interpreter Assistance</h3>
              <p>Professional interpreter assistance available</p>
            </div>
            <div className="service-card">
              <div className="service-icon">💬</div>
              <h3>24/7 Support</h3>
              <p>Round the clock assistance throughout your journey</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}

export default Home

