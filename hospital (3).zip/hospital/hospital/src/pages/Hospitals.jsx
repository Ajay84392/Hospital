import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import { Search, MapPin, Star, Phone, Mail } from 'lucide-react'
import './Hospitals.css'

const Hospitals = () => {
  const [searchQuery, setSearchQuery] = useState('')

  const hospitals = [
    {
      id: 1,
      name: 'Apollo Hospital',
      location: 'Delhi',
      rating: 4.8,
      specialties: ['Cardiac Surgery', 'Cancer Treatment', 'Organ Transplant'],
      image: 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=400',
      phone: '+91-11-71791090',
      email: 'info@apollohospitals.com',
    },
    {
      id: 2,
      name: 'BLK Hospital',
      location: 'New Delhi',
      rating: 4.7,
      specialties: ['Cardiac Surgery', 'Orthopedic', 'ENT Surgery'],
      image: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1f?w=400',
      phone: '+91-11-30402020',
      email: 'info@blkhospital.com',
    },
    {
      id: 3,
      name: 'Manipal Hospital',
      location: 'Dwarka, Delhi',
      rating: 4.6,
      specialties: ['Orthopedic', 'Cardiac Surgery', 'General Surgery'],
      image: 'https://images.unsplash.com/photo-1551601651-2a8555f1a136?w=400',
      phone: '+91-11-47192020',
      email: 'info@manipalhospitals.com',
    },
    {
      id: 4,
      name: 'Max Hospital',
      location: 'Saket, Delhi',
      rating: 4.8,
      specialties: ['Cancer Treatment', 'Cardiac Surgery', 'Neurology'],
      image: 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=400',
      phone: '+91-11-26515050',
      email: 'info@maxhealthcare.com',
    },
    {
      id: 5,
      name: 'Fortis Escorts Heart Hospital',
      location: 'New Delhi',
      rating: 4.9,
      specialties: ['Cardiac Surgery', 'Pediatric Cardiac', 'Cardiology'],
      image: 'https://images.unsplash.com/photo-1559757175-0eb30cd8c063?w=400',
      phone: '+91-11-47135000',
      email: 'info@fortishealthcare.com',
    },
    {
      id: 6,
      name: 'Jaypee Hospital',
      location: 'Noida',
      rating: 4.5,
      specialties: ['General Surgery', 'Orthopedic', 'ENT Surgery'],
      image: 'https://images.unsplash.com/photo-1582750433449-648ed127bb54?w=400',
      phone: '+91-120-4122222',
      email: 'info@jaypeehealthcare.com',
    },
    {
      id: 7,
      name: 'Medanta Hospital',
      location: 'Gurgaon',
      rating: 4.7,
      specialties: ['Organ Transplant', 'Cardiac Surgery', 'Cancer Treatment'],
      image: 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=400',
      phone: '+91-124-4141414',
      email: 'info@medanta.org',
    },
    {
      id: 8,
      name: 'Artemis Hospital',
      location: 'Gurgaon',
      rating: 4.6,
      specialties: ['Cardiac Surgery', 'Orthopedic', 'Neurology'],
      image: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1f?w=400',
      phone: '+91-124-6767000',
      email: 'info@artemishospitals.com',
    },
  ]

  const filteredHospitals = hospitals.filter(hospital =>
    hospital.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    hospital.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
    hospital.specialties.some(s => s.toLowerCase().includes(searchQuery.toLowerCase()))
  )

  return (
    <div className="hospitals-page">
      <section className="page-hero">
        <div className="container">
          <h1 className="page-title">Top Hospitals in India</h1>
          <p className="page-subtitle">
            Connect with world-class hospitals offering advanced medical treatments
          </p>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="search-bar">
            <Search className="search-icon" size={20} />
            <input
              type="text"
              placeholder="Search hospitals by name, location, or specialty..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="search-input"
            />
          </div>

          <div className="results-info">
            <p>Found {filteredHospitals.length} hospitals</p>
          </div>

          <div className="hospitals-grid">
            {filteredHospitals.map(hospital => (
              <div key={hospital.id} className="hospital-card">
                <div className="hospital-image">
                  <img src={hospital.image} alt={hospital.name} />
                  <div className="hospital-rating">
                    <Star size={16} fill="#fbbf24" color="#fbbf24" />
                    <span>{hospital.rating}</span>
                  </div>
                </div>
                <div className="hospital-content">
                  <h3 className="hospital-name">{hospital.name}</h3>
                  <div className="hospital-location">
                    <MapPin size={16} />
                    <span>{hospital.location}</span>
                  </div>
                  <div className="hospital-specialties">
                    <h4>Specialties:</h4>
                    <div className="specialty-tags">
                      {hospital.specialties.map((specialty, idx) => (
                        <span key={idx} className="specialty-tag">{specialty}</span>
                      ))}
                    </div>
                  </div>
                  <div className="hospital-contact">
                    <div className="contact-item">
                      <Phone size={14} />
                      <span>{hospital.phone}</span>
                    </div>
                    <div className="contact-item">
                      <Mail size={14} />
                      <span>{hospital.email}</span>
                    </div>
                  </div>
                  <div className="hospital-actions">
                    <Link to="/contact" className="btn btn-primary">
                      Book Appointment
                    </Link>
                    <Link to="/doctors" className="btn btn-outline">
                      View Doctors
                    </Link>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {filteredHospitals.length === 0 && (
            <div className="no-results">
              <p>No hospitals found. Try adjusting your search.</p>
            </div>
          )}
        </div>
      </section>
    </div>
  )
}

export default Hospitals

