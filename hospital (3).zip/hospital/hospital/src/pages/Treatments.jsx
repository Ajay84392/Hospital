import React, { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { Search, Filter } from 'lucide-react'
import './Treatments.css'

const Treatments = () => {
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('all')

  const categories = [
    { id: 'all', name: 'All Treatments' },
    { id: 'brain-spine', name: 'Brain & Spine Surgery' },
    { id: 'cancer', name: 'Cancer Treatment' },
    { id: 'cardiac', name: 'Cardiac Surgery' },
    { id: 'cosmetic', name: 'Cosmetic Surgery' },
    { id: 'dental', name: 'Dental Treatment' },
    { id: 'ent', name: 'ENT Surgery' },
    { id: 'eye', name: 'Eye Treatment' },
    { id: 'transplant', name: 'Organ Transplant' },
    { id: 'orthopedic', name: 'Orthopedic Surgery' },
    { id: 'weight-loss', name: 'Weight Loss Treatment' },
  ]

  const treatments = [
    // Brain & Spine
    { id: 1, name: 'Brain Tumour Surgery', category: 'brain-spine', price: 8000 },
    { id: 2, name: 'Deep Brain Stimulation', category: 'brain-spine', price: 25000 },
    { id: 3, name: 'Endoscopic Spine Surgery', category: 'brain-spine', price: 12000 },
    { id: 4, name: 'Slipped Disc Surgery', category: 'brain-spine', price: 7000 },
    { id: 5, name: 'Scoliosis Surgery', category: 'brain-spine', price: 15000 },
    
    // Cancer
    { id: 6, name: 'Breast Cancer Treatment', category: 'cancer', price: 10000 },
    { id: 7, name: 'Liver Cancer Treatment', category: 'cancer', price: 18000 },
    { id: 8, name: 'Lung Cancer Treatment', category: 'cancer', price: 15000 },
    { id: 9, name: 'Bone Cancer Treatment', category: 'cancer', price: 20000 },
    
    // Cardiac
    { id: 10, name: 'Heart Bypass Surgery', category: 'cardiac', price: 7000 },
    { id: 11, name: 'Coronary Angioplasty', category: 'cardiac', price: 5000 },
    { id: 12, name: 'Valve Replacement Surgery', category: 'cardiac', price: 12000 },
    { id: 13, name: 'Pacemaker Implant', category: 'cardiac', price: 15000 },
    
    // Cosmetic
    { id: 14, name: 'Breast Augmentation', category: 'cosmetic', price: 4000 },
    { id: 15, name: 'Rhinoplasty Surgery', category: 'cosmetic', price: 3500 },
    { id: 16, name: 'Liposuction', category: 'cosmetic', price: 3000 },
    { id: 17, name: 'Hair Transplant', category: 'cosmetic', price: 2500 },
    
    // Dental
    { id: 18, name: 'Dental Bridges', category: 'dental', price: 800 },
    { id: 19, name: 'Hollywood Smile', category: 'dental', price: 2000 },
    
    // ENT
    { id: 20, name: 'Cochlear Implant', category: 'ent', price: 17000 },
    { id: 21, name: 'Goiter Removal Surgery', category: 'ent', price: 3500 },
    { id: 22, name: 'Endoscopic Sinus Surgery', category: 'ent', price: 3000 },
    
    // Eye
    { id: 23, name: 'LASIK Eye Surgery', category: 'eye', price: 1500 },
    { id: 24, name: 'Cataract Surgery', category: 'eye', price: 1200 },
    { id: 25, name: 'Retina Surgery', category: 'eye', price: 4000 },
    { id: 26, name: 'Corneal Transplant', category: 'eye', price: 5000 },
    
    // Transplant
    { id: 27, name: 'Kidney Transplant', category: 'transplant', price: 14000 },
    { id: 28, name: 'Liver Transplant', category: 'transplant', price: 34000 },
    { id: 29, name: 'Heart Transplant', category: 'transplant', price: 50000 },
    { id: 30, name: 'Bone Marrow Transplant', category: 'transplant', price: 25000 },
    
    // Orthopedic
    { id: 31, name: 'Hip Replacement', category: 'orthopedic', price: 6500 },
    { id: 32, name: 'Knee Replacement', category: 'orthopedic', price: 3900 },
    { id: 33, name: 'Shoulder Replacement', category: 'orthopedic', price: 5500 },
    { id: 34, name: 'ACL Surgery', category: 'orthopedic', price: 4000 },
    
    // Weight Loss
    { id: 35, name: 'Gastric Bypass Surgery', category: 'weight-loss', price: 6000 },
    { id: 36, name: 'Sleeve Gastrectomy', category: 'weight-loss', price: 5500 },
    { id: 37, name: 'Gastric Balloon', category: 'weight-loss', price: 3000 },
  ]

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search)
    const category = urlParams.get('category')
    const search = urlParams.get('search')
    if (category) setSelectedCategory(category)
    if (search) setSearchQuery(search)
  }, [])

  const filteredTreatments = treatments.filter(treatment => {
    const matchesCategory = selectedCategory === 'all' || treatment.category === selectedCategory
    const matchesSearch = treatment.name.toLowerCase().includes(searchQuery.toLowerCase())
    return matchesCategory && matchesSearch
  })

  return (
    <div className="treatments-page">
      <section className="page-hero">
        <div className="container">
          <h1 className="page-title">Medical Treatments</h1>
          <p className="page-subtitle">
            Find the best medical treatments in India at affordable prices
          </p>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="filters-section">
            <div className="search-bar">
              <Search className="search-icon" size={20} />
              <input
                type="text"
                placeholder="Search treatments..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="search-input"
              />
            </div>

            <div className="category-filters">
              <div className="filter-label">
                <Filter size={18} />
                <span>Filter by Category:</span>
              </div>
              <div className="category-buttons">
                {categories.map(cat => (
                  <button
                    key={cat.id}
                    className={`category-btn ${selectedCategory === cat.id ? 'active' : ''}`}
                    onClick={() => setSelectedCategory(cat.id)}
                  >
                    {cat.name}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="results-info">
            <p>Found {filteredTreatments.length} treatments</p>
          </div>

          <div className="treatments-grid">
            {filteredTreatments.map(treatment => (
              <div key={treatment.id} className="treatment-card">
                <div className="treatment-header">
                  <h3 className="treatment-name">{treatment.name}</h3>
                  <span className="treatment-category">
                    {categories.find(c => c.id === treatment.category)?.name}
                  </span>
                </div>
                <div className="treatment-price">
                  <span className="price-label">Starting from</span>
                  <span className="price-value">${treatment.price.toLocaleString()}</span>
                </div>
                <div className="treatment-actions">
                  <Link to="/contact" className="btn btn-primary">
                    Get Quote
                  </Link>
                  <Link to="/doctors" className="btn btn-outline">
                    Find Doctors
                  </Link>
                </div>
              </div>
            ))}
          </div>

          {filteredTreatments.length === 0 && (
            <div className="no-results">
              <p>No treatments found. Try adjusting your search or filters.</p>
            </div>
          )}
        </div>
      </section>
    </div>
  )
}

export default Treatments

