import React from 'react'
import { Link } from 'react-router-dom'
import { Phone, Mail, MapPin } from 'lucide-react'
import './Footer.css'

const Footer = () => {
  const currentYear = new Date().getFullYear()

  const quickLinks = [
    { name: 'About Us', path: '/about' },
    { name: 'Plan Your Travel', path: '/about#travel' },
    { name: 'Medical Tourism in India', path: '/about#tourism' },
    { name: 'Advantages', path: '/about#advantages' },
    { name: 'Second Opinion', path: '/contact' },
    { name: 'FAQs', path: '/about#faq' },
    { name: 'Privacy Policy', path: '/about#privacy' },
    { name: 'Terms & Conditions', path: '/about#terms' },
  ]

  const specialties = [
    'Brain and Spine Surgery',
    'Cancer Treatment',
    'Cardiac Surgery',
    'Cosmetic Surgery',
    'Dental Treatment',
    'ENT Surgery',
    'Eye Treatment',
    'Organ Transplant',
    'Orthopedic Surgery',
    'Weight Loss Treatment',
  ]

  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-content">
          <div className="footer-section">
            <h3 className="footer-title">Afyaassist India</h3>
            <p className="footer-description">
              The most trusted name in medical tourism with years of experience 
              in providing affordable and high-quality medical treatment to 
              international and domestic patients.
            </p>
            <div className="footer-contact">
              <div className="footer-contact-item">
                <MapPin size={18} />
                <span>Okhla Road, New Delhi, India</span>
              </div>
              <div className="footer-contact-item">
                <Phone size={18} />
                <a href="tel:+919582708782">+91-9582708782</a>
              </div>
              <div className="footer-contact-item">
                <Mail size={18} />
                <a href="mailto:treatmentquery@gmail.com">treatmentquery@gmail.com</a>
              </div>
            </div>
          </div>

          <div className="footer-section">
            <h4 className="footer-heading">Quick Links</h4>
            <ul className="footer-links">
              {quickLinks.map((link, idx) => (
                <li key={idx}>
                  <Link to={link.path}>{link.name}</Link>
                </li>
              ))}
            </ul>
          </div>

          <div className="footer-section">
            <h4 className="footer-heading">Our Specialties</h4>
            <ul className="footer-links">
              {specialties.map((specialty, idx) => (
                <li key={idx}>
                  <Link to={`/treatments?category=${specialty.toLowerCase().replace(/\s+/g, '-')}`}>
                    {specialty}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div className="footer-section">
            <h4 className="footer-heading">Get Free Quote</h4>
            <p className="footer-description">
              Get a personalized treatment plan and cost estimate from our 
              medical experts.
            </p>
            <Link to="/contact" className="btn btn-primary">
              Contact Us
            </Link>
          </div>
        </div>

        <div className="footer-bottom">
          <p>&copy; {currentYear} Afyaassist India. All rights reserved.</p>
          <p className="footer-powered">Powered by Afyaassist</p>
        </div>
      </div>
    </footer>
  )
}

export default Footer

