import React, { useState } from "react";
import { Link } from "react-router-dom";
import { Menu, X, Phone, Mail } from "lucide-react";
import "./Header.css";

const Header = () => {
    const [isMenuOpen, setIsMenuOpen] = useState(false);

    const toggleMenu = () => {
        setIsMenuOpen(!isMenuOpen);
    };

    const treatmentCategories = [
        {
            name: "Brain & Spine Surgery",
            path: "/treatments?category=brain-spine",
        },
        { name: "Cancer Treatment", path: "/treatments?category=cancer" },
        { name: "Cardiac Surgery", path: "/treatments?category=cardiac" },
        { name: "Cosmetic Surgery", path: "/treatments?category=cosmetic" },
        { name: "Dental Treatment", path: "/treatments?category=dental" },
        { name: "ENT Surgery", path: "/treatments?category=ent" },
        { name: "Eye Treatment", path: "/treatments?category=eye" },
        { name: "Organ Transplant", path: "/treatments?category=transplant" },
        { name: "Orthopedic Surgery", path: "/treatments?category=orthopedic" },
        {
            name: "Weight Loss Treatment",
            path: "/treatments?category=weight-loss",
        },
    ];

    return (
        <header className="header">
            <div className="header-top">
                <div className="container">
                    <div className="header-top-content">
                        <div className="header-contact">
                            <a
                                href="tel:+919582708782"
                                className="contact-item"
                            >
                                <Phone size={16} />
                                <span>+91-9582708782</span>
                            </a>
                            <a
                                href="mailto:treatmentquery@gmail.com"
                                className="contact-item"
                            >
                                <Mail size={16} />
                                <span>treatmentquery@gmail.com</span>
                            </a>
                        </div>
                        <div className="header-cta">
                            <Link to="/contact" className="btn-cta">
                                Get Free Quote
                            </Link>
                        </div>
                    </div>
                </div>
            </div>

            <nav className="navbar">
                <div className="container">
                    <div className="nav-content">
                        <Link to="/" className="logo">
                            <span className="logo-text">Afyaassist</span>
                            <span className="logo-subtitle">India</span>
                        </Link>

                        <ul
                            className={`nav-menu ${isMenuOpen ? "active" : ""}`}
                        >
                            <li>
                                <Link
                                    to="/"
                                    onClick={() => setIsMenuOpen(false)}
                                >
                                    Home
                                </Link>
                            </li>
                            <li className="dropdown">
                                <span>
                                    Treatments{" "}
                                    <span className="dropdown-arrow">▼</span>
                                </span>
                                <ul className="dropdown-menu">
                                    {treatmentCategories.map((cat, idx) => (
                                        <li key={idx}>
                                            <Link
                                                to={cat.path}
                                                onClick={() =>
                                                    setIsMenuOpen(false)
                                                }
                                            >
                                                {cat.name}
                                            </Link>
                                        </li>
                                    ))}
                                </ul>
                            </li>
                            <li>
                                <Link
                                    to="/hospitals"
                                    onClick={() => setIsMenuOpen(false)}
                                >
                                    Hospitals
                                </Link>
                            </li>
                            <li>
                                <Link
                                    to="/doctors"
                                    onClick={() => setIsMenuOpen(false)}
                                >
                                    Doctors
                                </Link>
                            </li>
                            <li>
                                <Link
                                    to="/about"
                                    onClick={() => setIsMenuOpen(false)}
                                >
                                    About Us
                                </Link>
                            </li>
                            <li>
                                <Link
                                    to="/contact"
                                    onClick={() => setIsMenuOpen(false)}
                                >
                                    Contact
                                </Link>
                            </li>
                        </ul>

                        <button className="menu-toggle" onClick={toggleMenu}>
                            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
                        </button>
                    </div>
                </div>
            </nav>
        </header>
    );
};

export default Header;
